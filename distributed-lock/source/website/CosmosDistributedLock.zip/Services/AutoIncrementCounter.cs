﻿using CosmosDistributedLock.Models;

namespace CosmosDistributedLock.Services
{
    public class AutoIncrementCounter
    {

        DistributedLock distributedLock;
        DistributedLockService distributedLockService;


        public AutoIncrementCounter()
        { 

            //Need to figure out how to instantiate DistributedLockService from here.
            //distributedLockService = new DistributedLockService();

        }

        public async Task<long> GetNextValueAsync(string counterName, string ownerId)
        {
            return await distributedLockService.AcquireLease(counterName, "owner1", 1);
        }

    }
}

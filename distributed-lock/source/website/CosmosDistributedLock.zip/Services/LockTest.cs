﻿namespace CosmosDistributedLock.Services
{
    public class LockTest
    {

        ///Create lots of instances of AutoIncrementCounter in here all on separate threads
        ///using same lock name with different owner ids.
    }
}
